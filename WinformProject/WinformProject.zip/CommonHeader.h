#pragma once
// ���� ���

#include "BaseForm.h"
#include "IFormValidator.h"

#include "Alert.h"
#include "CommConst.h"
#include "FileUtil.h"
#include "FileDlgUtil.h"
#include "StringUtil.h"