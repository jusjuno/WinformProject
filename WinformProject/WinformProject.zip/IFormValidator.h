#pragma once
/// <summary>
/// Form validation interface
/// </summary>
interface class IFormValidator
{
public:
	bool IsValidToOpenForm();
};