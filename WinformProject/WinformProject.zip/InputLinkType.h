#pragma once
namespace WinformProject {
	/// <summary>
	/// input link type
	/// </summary>
	public ref class InputLinkType
	{
	public:
		InputLinkType() {

		}
	public:

	};
}